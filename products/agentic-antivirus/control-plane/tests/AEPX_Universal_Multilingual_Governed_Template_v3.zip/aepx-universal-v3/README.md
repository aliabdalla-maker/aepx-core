# Universal AEP-X Agentic Application Template v3

Reusable specification for application development with AEP-X as the governed AI-agent interoperability layer. The template defines requirements and acceptance gates; it does not assert that all functionality has been implemented.

## Use
1. Edit `application.yaml` and provide application-specific requirements.
2. Pin and inspect a verified commit of https://github.com/aliabdalla-maker/aepx-core.
3. Execute the phases in `MASTER_PROMPT.md` on a feature branch.
4. Require test evidence, human approvals, and verified free-tier eligibility before any provisioning or deployment.

## Constraints
- No production mocks or unverified connector stubs.
- No merge, provisioning, production deployment, or publication without explicit approval.
- Arbitrary files may be stored as opaque blobs, but format-specific preview/edit/conversion requires a verified handler.
- Language support is a 100-locale target; each locale and speech voice must be tested and individually reported.
- Only authenticated and authorized operations may modify files, integrations, settings, or agent state.
