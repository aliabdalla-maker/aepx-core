import os, sqlite3, time, uuid
from contextlib import contextmanager
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

DB = os.getenv('BAM_DB', '/tmp/bam.db')
TOKEN = os.getenv('BAM_DEV_TOKEN', '')
app = FastAPI(title='Business AI Manager — development API', version='0.1.0')

app.add_middleware(CORSMiddleware, allow_origins=['http://127.0.0.1:8088','http://localhost:8088'], allow_methods=['GET','POST','PATCH','DELETE'], allow_headers=['Authorization','X-Tenant-ID','Content-Type'])

@contextmanager
def connection():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    try:
        yield db
        db.commit()
    finally:
        db.close()

def init():
    with connection() as db:
        db.executescript('''CREATE TABLE IF NOT EXISTS customers(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,name TEXT NOT NULL,email TEXT NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS tasks(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,title TEXT NOT NULL,status TEXT NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,tenant TEXT NOT NULL,action TEXT NOT NULL,resource TEXT NOT NULL,at REAL NOT NULL);''')
init()

class Customer(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    email: str = Field(min_length=3, max_length=254)
class Task(BaseModel):
    title: str = Field(min_length=1,max_length=200)
class TaskUpdate(BaseModel):
    status: str

def auth(tenant: str | None, authorization: str | None):
    # DEVELOPMENT ONLY. Replace with verified OIDC JWT, tenant membership and RBAC before production.
    if not TOKEN or authorization != 'Bearer ' + TOKEN or not tenant or len(tenant)>80:
        raise HTTPException(401,'Development token and tenant required')
    return tenant

def audit(db,tenant,action,resource):
    db.execute('INSERT INTO audit VALUES(?,?,?,?,?)',(str(uuid.uuid4()),tenant,action,resource,time.time()))

@app.get('/health')
def health(): return {'status':'ok','mode':'development','production_ready':False}

@app.post('/customers',status_code=201)
def create_customer(item:Customer,x_tenant_id:str|None=Header(None),authorization:str|None=Header(None)):
    tenant=auth(x_tenant_id,authorization); key=str(uuid.uuid4())
    with connection() as db:
        db.execute('INSERT INTO customers VALUES(?,?,?,?,?)',(key,tenant,item.name,item.email,time.time()))
        audit(db,tenant,'customer.created',key)
    return {'id':key,**item.model_dump()}

@app.get('/customers')
def customers(x_tenant_id:str|None=Header(None),authorization:str|None=Header(None)):
    tenant=auth(x_tenant_id,authorization)
    with connection() as db: return [dict(x) for x in db.execute('SELECT id,name,email,created FROM customers WHERE tenant=? ORDER BY created DESC',(tenant,))]

@app.delete('/customers/{key}')
def delete_customer(key:str,x_tenant_id:str|None=Header(None),authorization:str|None=Header(None)):
    tenant=auth(x_tenant_id,authorization)
    with connection() as db:
        result=db.execute('DELETE FROM customers WHERE id=? AND tenant=?',(key,tenant))
        if not result.rowcount: raise HTTPException(404,'Not found')
        audit(db,tenant,'customer.deleted',key)
    return {'deleted':True}

@app.post('/tasks',status_code=201)
def create_task(item:Task,x_tenant_id:str|None=Header(None),authorization:str|None=Header(None)):
    tenant=auth(x_tenant_id,authorization); key=str(uuid.uuid4())
    with connection() as db:
        db.execute('INSERT INTO tasks VALUES(?,?,?,?,?)',(key,tenant,item.title,'open',time.time()))
        audit(db,tenant,'task.created',key)
    return {'id':key,'title':item.title,'status':'open'}

@app.get('/tasks')
def tasks(x_tenant_id:str|None=Header(None),authorization:str|None=Header(None)):
    tenant=auth(x_tenant_id,authorization)
    with connection() as db:return [dict(x) for x in db.execute('SELECT id,title,status,created FROM tasks WHERE tenant=? ORDER BY created DESC',(tenant,))]

@app.patch('/tasks/{key}')
def update_task(key:str,item:TaskUpdate,x_tenant_id:str|None=Header(None),authorization:str|None=Header(None)):
    tenant=auth(x_tenant_id,authorization)
    if item.status not in ('open','done'):raise HTTPException(422,'Invalid status')
    with connection() as db:
        result=db.execute('UPDATE tasks SET status=? WHERE id=? AND tenant=?',(item.status,key,tenant))
        if not result.rowcount:raise HTTPException(404,'Not found')
        audit(db,tenant,'task.updated',key)
    return {'id':key,'status':item.status}

@app.get('/dashboard')
def dashboard(x_tenant_id:str|None=Header(None),authorization:str|None=Header(None)):
    tenant=auth(x_tenant_id,authorization)
    with connection() as db:
        def count(query):return db.execute(query,(tenant,)).fetchone()[0]
        return {'customers':count('SELECT COUNT(*) FROM customers WHERE tenant=?'), 'tasks_open':count("SELECT COUNT(*) FROM tasks WHERE tenant=? AND status='open'"),'tasks_done':count("SELECT COUNT(*) FROM tasks WHERE tenant=? AND status='done'"),'audit_events':count('SELECT COUNT(*) FROM audit WHERE tenant=?'),'source':'sqlite','production_ready':False}
