import os,tempfile
fd,path=tempfile.mkstemp();os.close(fd)
os.environ['BAM_DB']=path
os.environ['BAM_DEV_TOKEN']='local-test-token'
from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def headers(tenant):return {'Authorization':'Bearer local-test-token','X-Tenant-ID':tenant}
def test_auth_and_tenant_isolation():
    assert client.get('/customers').status_code==401
    response=client.post('/customers',headers=headers('alpha'),json={'name':'Test','email':'test@example.org'})
    assert response.status_code==201
    key=response.json()['id']
    assert len(client.get('/customers',headers=headers('alpha')).json())==1
    assert client.get('/customers',headers=headers('beta')).json()==[]
    assert client.delete('/customers/'+key,headers=headers('beta')).status_code==404
    assert client.get('/dashboard',headers=headers('alpha')).json()['customers']==1
    assert client.delete('/customers/'+key,headers=headers('alpha')).status_code==200
def test_tasks():
    r=client.post('/tasks',headers=headers('alpha'),json={'title':'Call customer'})
    assert r.status_code==201
    key=r.json()['id']
    assert client.patch('/tasks/'+key,headers=headers('beta'),json={'status':'done'}).status_code==404
    assert client.patch('/tasks/'+key,headers=headers('alpha'),json={'status':'done'}).status_code==200
    assert client.get('/dashboard',headers=headers('alpha')).json()['tasks_done']==1
