# Business AI Manager — runnable development slice

This is a **tested development starter**, NOT a production-ready release, NOT integrated with the live AEP-X services, and NOT a signed mobile/desktop application. It implements a persistent SQLite API for tenant-scoped customers, tasks, audit events and live database-backed dashboard counters. Its bearer token and tenant header are explicitly development-only; client-supplied tenant identifiers are NOT adequate production authorization.

## Run locally

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
export BAM_DEV_TOKEN=change-me-locally
uvicorn app.main:app --reload
pytest -q
```

Windows PowerShell: `.venv\\Scripts\\Activate.ps1` and `$env:BAM_DEV_TOKEN='change-me-locally'`.

Open http://127.0.0.1:8000/docs and use bearer token and `X-Tenant-ID` header for requests. Docker: `BAM_DEV_TOKEN=change-me-locally docker compose up --build` (Linux/macOS); in PowerShell set `$env:BAM_DEV_TOKEN` first.

## Release blockers (must be completed before any public exposure)

1. Replace development bearer-token and tenant header with verified OIDC JWT claims, server-side tenant membership and RBAC; add abuse limits, CSRF protections where appropriate and production CORS.
2. Replace SQLite with PostgreSQL, tenant RLS, migrations, backup/restore verification, secret management and encrypted transport.
3. Integrate and test actual AEP-X gateway, policy, MCP approvals, worker fencing, budgets and auditable tool calls. Never bypass AEP-X governance.
4. Implement sales, communications, automations, reports, agent jobs, consent and user administration with real providers; no dummy connectors counted as complete.
5. Implement responsive web UI and accessibility; build and test Android, iOS, Windows, macOS, Linux wrappers/clients and signing pipelines on supported build runners.
6. Add integration, concurrency, adversarial, load, accessibility, mobile and end-to-end tests; publish exact-SHA evidence, test results, SBOM and release artifacts.
7. Check OCI uk-london-1 tenancy Always Free quotas and capacity before ANY provisioning. Do not create paid resources or enable fallback.
8. Require human approval for merges, signing, OCI production changes, website publication and app store submissions. No deployment is configured in this starter.

## Integration location

Proposed additive location in `aliabdalla-maker/aepx-core`: `applications/business-ai-manager/`. Inspect existing platform and service contracts before adapting. This standalone starter has not modified that repository.

## Local web console

From the `web` directory run `python -m http.server 8088 --bind 127.0.0.1`, then visit http://127.0.0.1:8088. The console performs real API calls and displays persisted dashboard counters. It is intentionally development-only and has no production authentication.
